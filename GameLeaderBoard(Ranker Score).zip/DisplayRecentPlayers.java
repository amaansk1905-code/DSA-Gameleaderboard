package project;

class DisplayRecentPlayers {
	AddPlayer ap;
	public DisplayRecentPlayers(AddPlayer ap)
	{
		this.ap = ap;
	}
	public void addRecentPlayer(Gamer p) {
		Gamer tempCheck = ap.recentHead;
		Gamer prev = null;
		while(tempCheck != null)
		{
			if(tempCheck.playerID == p.playerID)
			{
				if(prev == null)
				{
					ap.recentHead = tempCheck.next;
				}
				else
				{
					prev.next = tempCheck.next;
				}
				break;
			}
			prev = tempCheck;
			tempCheck = tempCheck.next;
		}
		Gamer newNode = new Gamer(p.playerID, p.playerName);
		newNode.next = ap.recentHead;
		ap.recentHead = newNode;

		int count = 1;
		Gamer temp = ap.recentHead;
		while (temp != null && temp.next != null) {
			if (count == 5) {
				temp.next = null; 
				break;
			}
			temp = temp.next;
			count++;
		}
	}
	public void displayRecentPlayers() {
		System.out.println("\n=== RECENTLY ACTIVE (LAST 5) ===");
		Gamer temp = ap.recentHead;
		if (temp == null) System.out.println("No recent activity.");
    
		while (temp != null) {
			System.out.println("-> " + temp.playerName);
			temp = temp.next;
		}
	}
}
