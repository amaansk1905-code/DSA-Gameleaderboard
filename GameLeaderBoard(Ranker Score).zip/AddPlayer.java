package project;

class AddPlayer {
	FileWrite fw = new FileWrite();
	HashTable hash;
	public AddPlayer(HashTable hash)
	{
		this.hash = hash;
	}
	Gamer head = null;          
    Gamer recentHead = null;    
    Gamer tournamentHead = null;
    
    int playerCount = 0;
    final int MAX_PLAYERS = 20;
    
    public int generateID(String name) {
    	//
        char first = Character.toUpperCase(name.charAt(0));
        return 100 + (first - 'A' + 1) + (int)(Math.random() * 10);
    }

    public void addPlayer(String name) {
        if (playerCount >= MAX_PLAYERS) {
            System.out.println("\n[!] Error: Server Full. Maximum 20 players allowed.");
            return;
        }

        int id;

        do
        {
            id = generateID(name);
        }while(hash.isIDExists(id));

        Gamer newPlayer = new Gamer(id, name);

        if (head == null) {
            head = newPlayer;
        } else {
            Gamer temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newPlayer;
        }
        playerCount++;
        
        hash.insertHash(newPlayer);
        fw.saveAllPlayers(this);
        System.out.println("\n--- REGISTRATION SUCCESSFUL ---");
        System.out.println("Welcome " + name + "! You have been granted 500 starting coins.");
        newPlayer.displayStats();
    }
}
