package project;

class DisplayTournamentPlayers {
	AddPlayer ap;
	public DisplayTournamentPlayers(AddPlayer ap)
	{
		this.ap = ap;
	}

	public void addTournamentPlayer(Gamer p) {
		Gamer tempCheck = ap.tournamentHead;
		while(tempCheck != null)
		{
			if(tempCheck.playerID == p.playerID)
			{
				return;
			}
			tempCheck = tempCheck.next;
		}
		Gamer newNode = new Gamer(p.playerID, p.playerName);
		if (ap.tournamentHead == null) {
			ap.tournamentHead = newNode;
		} else {
			Gamer temp = ap.tournamentHead;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = newNode;
		}
	}

	public void displayTournamentPlayers() {
		System.out.println("\n=== TOURNAMENT ROSTER ===");
		Gamer temp = ap.tournamentHead;
		if (temp == null) System.out.println("Roster is currently empty.");
    
		while (temp != null) {
			System.out.println("[Entry] " + temp.playerName);
			temp = temp.next;
		}
	}
}
