package project;

import java.util.Scanner;

public class GamerLeaderBoard {
	
public static void main(String[] args) {
    	
        Scanner sc = new Scanner(System.in);
        
        HashTable hash = new HashTable();
        AddPlayer ap = new AddPlayer(hash);
        FileWrite fw = new FileWrite();
        DisplayLeaderBoard dlb = new DisplayLeaderBoard(hash,ap);
        DisplayRecentPlayers drp = new DisplayRecentPlayers(ap);
        DisplayTournamentPlayers dtp = new DisplayTournamentPlayers(ap);
        DeletePlayer dp = new DeletePlayer(hash,ap);
        PlayGame pg = new PlayGame(hash,drp,dtp);
        MaxPriorityRanks mpr = new MaxPriorityRanks(hash, ap, 20);
        
        int choice;

        System.out.println("=============================================");
        System.out.println("        BATTLE GROUND ARENA DASHBOARD        ");
        System.out.println("=============================================");

        System.out.println("Loading Previous Data");
        fw.loadPlayers(ap,hash);
        
        do {
            System.out.println("\n1. Register New Player");
            System.out.println("2. Enter Battle Arena (Play)");
            System.out.println("3. View Top 3 Players");
            System.out.println("4. View Full Leaderboard");
            System.out.println("5. View Recent Activity");
            System.out.println("6. View Tournament Roster");
            System.out.println("7. Search Player ID");
            System.out.println("8. Delete from Game");
            System.out.println("9. Undo Delete Player");
            System.out.println("10. Display Ranks");
            System.out.println("11. Exit System");     
            System.out.print("Select an option: ");
            
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    sc.nextLine(); 
                    System.out.print("Enter Player Name: ");
                    String name = sc.nextLine();
                    ap.addPlayer(name);
                    break;
                case 2:
                    System.out.print("Enter your Player ID to login: ");
                    int Id = sc.nextInt();
                    pg.playGame(Id);
                    break;
                case 3: dlb.displayLeaderboard(3); break;   
                case 4: dlb.displayLeaderboard(-1); break;  
                case 5: drp.displayRecentPlayers(); break;
                case 6: dtp.displayTournamentPlayers(); break;
                case 7:
                    System.out.print("Enter Player ID to search: ");
                    int id = sc.nextInt();
                    Gamer found = hash.searchByHash(id);
                    if (found != null) {
                        System.out.println("\n--- PLAYER FOUND ---");
                        found.displayStats();
                    } else {
                        System.out.println("\n[!] Player not found.");
                    }
                    break;
                case 8:
                		System.out.print("Enter Player ID to delete account: ");
                		int ID = sc.nextInt();
                		dp.deletePlayer(ID);
                		break;
                case 9:
                		dp.undoDeletePlayer();
                		break;
                case 10:
                		sc.nextLine();
                		mpr.displayRanks();
                		break;
                case 11: System.out.println("\nShutting down system. Goodbye!");
                		break;
                default: System.out.println("\n[!] Invalid option. Try again.");
            }
        } while (choice != 11);

        sc.close();
    }
}
