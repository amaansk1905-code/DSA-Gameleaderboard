package project;

class HashTable {
	Gamer [] hashTable = new Gamer[20];
    int tableSize = 20;
    
    public void insertHash(Gamer player)
    {
        int index = player.playerID % tableSize;

        Gamer newNode = new Gamer(player.playerID, player.playerName);
        newNode.coins = player.coins;

        if(hashTable[index] == null)
        {
            hashTable[index] = newNode;
        }
        else
        {
            Gamer temp = hashTable[index];
            while(temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }
    
    public Gamer searchByHash(int id)
    {
        int index = id % tableSize;

        Gamer temp = hashTable[index];

        while(temp != null)
        {
            if(temp.playerID == id)
            {
                return temp;
            }
            temp = temp.next;
        }

        return null;
    }
    
    public void deleteFromHash(int id)
    {
        int index = id % tableSize;

        Gamer temp = hashTable[index];
        Gamer prev = null;

        while(temp != null && temp.playerID != id)
        {
            prev = temp;
            temp = temp.next;
        }

        if(temp == null)
        {
            return;
        }

        if(prev == null)
        {
            hashTable[index] = temp.next;
        }
        else
        {
            prev.next = temp.next;
        }
    }
    
    public boolean isIDExists(int id)
    {
        int index = id % tableSize;

        Gamer temp = hashTable[index];

        while(temp != null)
        {
            if(temp.playerID == id)
            {
                return true;
            }
            temp = temp.next;
        }

        return false;
    }
}
