package project;
import java.io.*;
public class FileCreate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			File fc = new File("gameLeaderBoard.txt");
			if(fc.createNewFile())
			{
				System.out.println("File created with the name "+fc.getName());
			}
			else
			{
				System.out.println("File already created in the path "+fc.getAbsolutePath());
			}
		}
		catch(IOException io)
		{
			System.out.println("File cannot be create");
			io.printStackTrace();
		}
	}

}
