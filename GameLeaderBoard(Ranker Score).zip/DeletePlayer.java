package project;

class DeletePlayer {
	FileWrite fw = new FileWrite();
	HashTable hash;
	AddPlayer ap;
	public DeletePlayer(HashTable hash, AddPlayer ap)
	{
		this.hash = hash;
		this.ap = ap;
	}
	Gamer top = null;

    void push(Gamer player) {
        player.next = top;
        top = player;
    }

    Gamer pop() {
        if (top == null) return null;

        Gamer temp = top;
        top = top.next;

        temp.next = null; 
        return temp;
    }
    
    public void deletePlayer(int id) {

        if (ap.head == null) {
            System.out.println("\n[!] No players registered.");
            return;
        }

        Gamer temp = ap.head;
        Gamer prev = null;

        while (temp != null && temp.playerID != id) {
            prev = temp;
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("\n[!] Player not found.");
            return;
        }
        if (prev == null) {
            ap.head = ap.head.next;
        } else {
            prev.next = temp.next;
        }
        temp.next = null;
        push(temp);
        ap.playerCount--;

        hash.deleteFromHash(id);
        fw.saveAllPlayers(ap);
        System.out.println("\n=== PLAYER ACCOUNT DELETED ===");
        System.out.println("Player Removed: " + temp.playerName + " (ID: " + temp.playerID + ")");
    }
    
    public void undoDeletePlayer() {

        Gamer restore = pop();
        if (restore == null) {
            System.out.println("\n[!] No deleted players to restore.");
            return;
        }
        if(hash.isIDExists(restore.playerID))
        {
        		System.out.println("\n[!] Player already exists. Cannot restore.");
        }
        
        if(ap.head == null)
        {
        		ap.head = restore;
        }
        else
        {
        		Gamer temp = ap.head;
        		while(temp.next != null)
        		{
        			temp = temp.next;
        		}
        		temp.next = restore;
        }
        hash.insertHash(restore);
        ap.playerCount++;
        fw.saveAllPlayers(ap);
        System.out.println("\n=== UNDO SUCCESSFUL ===");
        System.out.println("Player Restored: " + restore.playerName + " (ID: " + restore.playerID + ")");
    }
}
