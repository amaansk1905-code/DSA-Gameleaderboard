package project;

class DisplayLeaderBoard {
	HashTable hash;
	AddPlayer ap;
	public DisplayLeaderBoard(HashTable hash, AddPlayer ap)
	{
		this.hash = hash;
		this.ap = ap;
	}
	
	public void displayLeaderboard(int limit) {

        if (ap.playerCount == 0) {
            System.out.println("\n[!] No players registered yet.");
            return;
        }

        Gamer[] arr = new Gamer[ap.playerCount];
        int index = 0;

        for (int i = 0; i < hash.tableSize; i++) {

            Gamer temp = hash.hashTable[i];

            while (temp != null) {

                arr[index] = temp;
                index++;

                temp = temp.next;
            }
        }

        int n = index;

        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }

        for (int i = n - 1; i > 0; i--) {

            Gamer temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            heapify(arr, i, 0);
        }

        int displayCount = (limit == -1) ? n : 3 ;

        System.out.println("\n=== LEADERBOARD ===");

        for (int i = n - 1; i >= n - displayCount; i--) {

            System.out.println(
                arr[i].playerName + " - " + arr[i].coins + " coins"
            );
        }
    }

    private void heapify(Gamer[] arr, int n, int i) {
        int largest = i; 
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].coins > arr[largest].coins) largest = left;
        if (right < n && arr[right].coins > arr[largest].coins) largest = right;

        if (largest != i) {
            Gamer temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;
            heapify(arr, n, largest);
        }
    }
}
