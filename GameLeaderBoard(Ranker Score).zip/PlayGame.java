package project;
import java.util.Scanner;
class PlayGame {
	Scanner sc = new Scanner(System.in);
	FileWrite fw = new FileWrite();
	HashTable hash;
	DisplayRecentPlayers drp;
	DisplayTournamentPlayers dtp;
	public PlayGame(HashTable hash, DisplayRecentPlayers drp, DisplayTournamentPlayers dtp)
	{
		this.hash = hash;
		this.drp = drp;
		this.dtp = dtp;
	}
	public void playGame(int id) {
        Gamer player = hash.searchByHash(id);
        if (player == null) {
            System.out.println("\n[!] Player not found. Please check the ID or register.");
            return;
        }

        if (player.coins <= 0) {
            System.out.println("\n[!] You are out of coins! Game Over for " + player.playerName + ".");
            return;
        }

        System.out.println("\n=== SESSION STARTED: " + player.playerName + " ===");
        
        int choice;
        do {
            System.out.println("\n--- BATTLE MENU ---");
            System.out.println("Balance: " + player.coins + " Coins");
            System.out.println("1. Launch Attack (Risk Coins)");
            System.out.println("2. Buy Shield/Heal (Costs 50 Coins)");
            System.out.println("3. End Session");
            System.out.print("Choose action: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: attack(player); break;
                case 2: heal(player); break;
                case 3: System.out.println("Saving stats and exiting match..."); break;
                default: System.out.println("Invalid choice.");
            }
            if (player.coins <= 0) {
                System.out.println("\n[!] You have lost all your coins! You are eliminated.");
                choice = 3; 
            }

        } while (choice != 3);

        player.score = player.coins; 
        drp.addRecentPlayer(player);
        dtp.addTournamentPlayer(player);
        fw.saveAllPlayers(drp.ap);
    }

    private void attack(Gamer player) {
        System.out.print("Enter your bet amount (Max " + player.coins + "): ");
        int bet = sc.nextInt();

        if (bet > player.coins) {
            System.out.println("[!] Invalid bet. Must be between 50 and your current balance.");
            return;
        }

        System.out.print("Guess the enemy's weak point (Enter a number between 10 and 99): ");
        int guess = sc.nextInt();

        if (guess < 10 || guess > 99) {
            System.out.println("[!] Invalid input. Two-digit numbers only.");
            return;
        }

        int enemyWeakPoint = (int)(Math.random() * 90) + 10;
        System.out.println("\n>> Enemy Weak Point Revealed: " + enemyWeakPoint);

        if (guess == enemyWeakPoint) {
            int winnings = bet * 3;
            player.coins += winnings;
            System.out.println(">> CRITICAL HIT! Perfect match. You won " + winnings + " coins!");
        } else if (Math.abs(guess - enemyWeakPoint) <= 5) {
            int winnings = bet; 
            player.coins += winnings;
            System.out.println(">> GLANCING BLOW! Close call. You won " + winnings + " coins.");
        } else {
            player.coins -= bet;
            System.out.println(">> MISS! The enemy dodged. You lost " + bet + " coins.");
        }
    }

    private void heal(Gamer player) {
        if (player.coins < 50) {
            System.out.println("[!] Not enough coins to heal. Requires 50 coins.");
            return;
        }
        player.coins -= 50;
        System.out.println(">> Shield activated! You spent 50 coins to fortify your defenses.");
    }
}
