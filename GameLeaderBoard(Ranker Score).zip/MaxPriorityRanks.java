package project;

class MaxPriorityRanks {
	HashTable hash;
	AddPlayer ap;
    Gamer[] heap;
    int size;
    
    MaxPriorityRanks(HashTable hash, AddPlayer ap, int capacity) {
    		this.hash = hash;
    		this.ap = ap;
        heap = new Gamer[capacity];
        size = 0;
    }

    void insertHeap(Gamer player) {
        heap[size] = player;
        int current = size;
        size++;

        while (current > 0 && heap[current].coins > heap[(current - 1) / 2].coins) {

            Gamer temp = heap[current];
            heap[current] = heap[(current - 1) / 2];
            heap[(current - 1) / 2] = temp;

            current = (current - 1) / 2;
        }
    }

    Gamer extractMax() {
        if (size == 0) return null;

        Gamer max = heap[0];
        heap[0] = heap[size - 1];
        size--;

        heapify(0);
        return max;
    }

    void heapify(int i) {

        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < size && heap[left].coins > heap[largest].coins)
            largest = left;

        if (right < size && heap[right].coins > heap[largest].coins)
            largest = right;

        if (largest != i) {

            Gamer temp = heap[i];
            heap[i] = heap[largest];
            heap[largest] = temp;

            heapify(largest);
        }
    }

    public void displayRanks() {
        if (ap.playerCount == 0) {
            System.out.println("\n[!] No players available.");
            return;
        }
        size = 0;
        for (int i = 0; i < hash.tableSize; i++) {

            Gamer temp = hash.hashTable[i];

            while (temp != null) {
                insertHeap(temp);   
                temp = temp.next;
            }
        }

        System.out.println("\n=== PLAYER RANKINGS (Using Max Priority Queue) ===");

        int rank = 1;

        while (size > 0) {

            Gamer top = extractMax();

            top.rank = rank;

            System.out.println(
                "Rank " + rank +
                " -> " + top.playerName +
                " | Coins: " + top.coins +
                " | ID: " + top.playerID
            );

            rank++;
        }
    }
}