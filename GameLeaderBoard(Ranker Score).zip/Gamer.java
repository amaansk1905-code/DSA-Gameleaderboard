package project;

class Gamer {

    int playerID;
    String playerName;
    int coins;
    int score;
    int rank;
    Gamer next;

    Gamer(int id, String name) {
        this.playerID = id;
        this.playerName = name;
        this.coins = 500; 
        this.score = 0;
        this.rank = 0;
        this.next = null;
    }

    public void displayStats() {
        System.out.println("ID: " + playerID + " | Name: " + playerName + " | Coins: " + coins);
    }
}
