package project;
import java.io.*;
public class FileWrite {

	public void loadPlayers(AddPlayer ap, HashTable hash) {
        try {
            File fc = new File("gameLeaderBoard.txt"); 

            BufferedReader br = new BufferedReader(new FileReader(fc));
            String line;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");

                int id = Integer.parseInt(data[0]);
                String name = data[1];
                int coins = Integer.parseInt(data[2]);

                Gamer player = new Gamer(id, name);
                player.coins = coins;

                if (ap.head == null) {
                    ap.head = player;
                } else {
                    Gamer temp = ap.head;
                    while (temp.next != null) temp = temp.next;
                    temp.next = player;
                }

                ap.playerCount++;

                hash.insertHash(player);
            }

            br.close();

        } catch (IOException io) {
            System.out.println("Error loading file.");
            io.printStackTrace();
        }
    }

    public void saveAllPlayers(AddPlayer ap) {
        try {
        	    FileWriter fw = new FileWriter("gameLeaderBoard.txt");
            BufferedWriter bw = new BufferedWriter(fw);

            Gamer temp = ap.head;

            while (temp != null) {
                bw.write(temp.playerID + "," + temp.playerName + "," + temp.coins);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();

        } catch (IOException io) {
            System.out.println("Error saving file.");
            io.printStackTrace();
        }
    }

}
